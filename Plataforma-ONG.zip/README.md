# Plataforma ONG — Entrega Unidade 1 (HTML5)
Projeto acadêmico de site para ONGs utilizando HTML5, CSS3 e JS.