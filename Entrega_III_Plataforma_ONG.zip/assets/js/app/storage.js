const KEY_CADASTROS = 'ong:cads';
const KEY_PROJECTS = 'ong:projects';

export function saveCadastro(obj){
  const all = JSON.parse(localStorage.getItem(KEY_CADASTROS) || '[]');
  all.push({...obj, createdAt: new Date().toISOString()});
  localStorage.setItem(KEY_CADASTROS, JSON.stringify(all));
}

export function getAllProjects(){
  return JSON.parse(localStorage.getItem(KEY_PROJECTS) || '[]');
}

export function saveProject(project){
  const all = JSON.parse(localStorage.getItem(KEY_PROJECTS) || '[]');
  all.push({...project, createdAt: new Date().toISOString()});
  localStorage.setItem(KEY_PROJECTS, JSON.stringify(all));
}
