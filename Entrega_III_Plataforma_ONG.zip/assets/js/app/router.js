import { renderPage } from './templates.js';

const routes = {
  '': 'home',
  '#home': 'home',
  '#projetos': 'projetos',
  '#cadastro': 'cadastro'
};

export function initRouter() {
  window.addEventListener('hashchange', onRouteChange);
  onRouteChange();
}

function onRouteChange() {
  const hash = window.location.hash || '#home';
  const page = routes[hash] || 'home';
  renderPage(page);
}
