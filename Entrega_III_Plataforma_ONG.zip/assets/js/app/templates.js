import { getAllProjects } from './projects.js';

const container = () => document.getElementById('app') || document.querySelector('main');

export function mountUI(){
  if(!container()){
    const main = document.createElement('main');
    main.id = 'app';
    document.body.appendChild(main);
  }
  renderPage('home');
}

export function renderPage(page){
  const el = container();
  el.innerHTML = '';
  if(page === 'home') el.appendChild(homeTemplate());
  if(page === 'projetos') el.appendChild(projetosTemplate());
  if(page === 'cadastro') el.appendChild(cadastroTemplate());
}

function homeTemplate(){
  const div = document.createElement('div');
  div.innerHTML = '<h1>Bem-vindo</h1><p>Conheça nossos projetos e como ajudar.</p>';
  return div;
}

function projetosTemplate(){
  const div = document.createElement('div');
  const projects = getAllProjects();
  let inner = '<h1>Projetos</h1><div class="grid">';
  projects.forEach(p => {
    inner += `<article class="card"><h2>${p.title}</h2><p>${p.description}</p></article>`;
  });
  inner += '</div>';
  div.innerHTML = inner;
  return div;
}

function cadastroTemplate(){
  const div = document.createElement('div');
  div.innerHTML = `
    <h1>Cadastro</h1>
    <form id="cadastro-spa" novalidate>
      <label>Nome <input type="text" name="nome" required minlength="3"></label>
      <label>Email <input type="email" name="email" required></label>
      <label>CPF <input type="text" name="cpf" id="cpf" required></label>
      <button type="submit">Enviar</button>
    </form>
    <div id="form-feedback" aria-live="polite"></div>
  `;
  return div;
}
