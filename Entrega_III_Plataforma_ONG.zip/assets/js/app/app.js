import { initRouter } from './router.js';
import { mountUI } from './templates.js';
import { initForms } from './forms.js';
import { initProjects } from './projects.js';

document.addEventListener('DOMContentLoaded', () => {
  mountUI();
  initRouter();
  initForms();
  initProjects();
});
