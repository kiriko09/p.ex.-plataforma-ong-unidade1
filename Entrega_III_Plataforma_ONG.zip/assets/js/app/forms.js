import { saveCadastro } from './storage.js';

export function initForms(){
  document.body.addEventListener('submit', (ev) => {
    if(ev.target && ev.target.id === 'cadastro-spa'){
      ev.preventDefault();
      handleCadastroForm(ev.target);
    }
  });
}

function handleCadastroForm(form){
  const data = Object.fromEntries(new FormData(form));
  const feedbackEl = document.getElementById('form-feedback');
  const errors = validateCadastro(data);
  if(errors.length){
    feedbackEl.innerHTML = '<div class="alert alert-error">' + errors.join('<br>') + '</div>';
    return;
  }
  saveCadastro(data);
  feedbackEl.innerHTML = '<div class="alert alert-success">Cadastro salvo com sucesso.</div>';
  form.reset();
}

function validateCadastro(data){
  const errs = [];
  if(!data.nome || data.nome.trim().length < 3) errs.push('Nome deve ter pelo menos 3 caracteres.');
  if(!data.email || !/\S+@\S+\.\S+/.test(data.email)) errs.push('E-mail inválido.');
  if(!data.cpf || !/^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(data.cpf)) errs.push('CPF inválido.');
  return errs;
}
