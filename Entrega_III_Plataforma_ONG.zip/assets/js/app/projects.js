import { saveProject, getAllProjects } from './storage.js';

export function initProjects(){
  if(getAllProjects().length === 0){
    saveProject({ title: 'Projeto Educação Viva', description: 'Apoio escolar em comunidades.' });
  }
}

export function getAllProjects() {
  return JSON.parse(localStorage.getItem('ong:projects') || '[]');
}
