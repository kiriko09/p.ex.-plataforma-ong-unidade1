# Plataforma-ONG

**Repositório exemplo para Entregas I–IV — Plataforma para ONGs**

## Visão geral
Plataforma web que permite ONGs gerenciar projetos, captar recursos e engajar voluntários. Projeto desenvolvido como atividade acadêmica (Entregas I a IV).

## Estrutura do repositório
- `index.html`, `projetos.html`, `cadastro.html`
- `assets/css/` — estilos (variables, layout, components)
- `assets/js/app/` — código JS modular (SPA, router, templates, forms, storage)
- `.github/workflows/` — CI & deploy
- `docs/screenshots/` — screenshots de desktop e mobile
- `dist/` — build de produção (gerado por `npm run build`)

## Deploy (GitHub Pages)
Este projeto está configurado para publicar via GitHub Actions em `gh-pages` (workflow dispara em push para `main`). O site público ficará disponível em:
`https://Kiriko09.github.io/Plataforma-ONG/` (substitua `Kiriko09` pelo seu usuário caso altere).

## Como rodar localmente
1. `git clone https://github.com/Kiriko09/Plataforma-ONG.git`
2. `cd Plataforma-ONG`
3. `npm install`
4. `npm run build`
5. `npx serve dist` (ou abrir `dist/index.html` no navegador)

## Versionamento & Branching
Segue GitFlow: `develop`, `main`, `feature/*`, `release/*`, `hotfix/*`.
Commits seguem Conventional Commits.

## Acessibilidade (WCAG 2.1 AA)
Checklist implementado e testes recomendados com `axe-core` e `pa11y`.

## Licença
MIT
