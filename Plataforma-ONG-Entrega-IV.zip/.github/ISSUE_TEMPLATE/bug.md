---
name: Bug report
about: Reportar um bug encontrado no projeto
---

**Passos para reproduzir**
1. ...
2. ...

**Comportamento atual**
...

**Comportamento esperado**
...
