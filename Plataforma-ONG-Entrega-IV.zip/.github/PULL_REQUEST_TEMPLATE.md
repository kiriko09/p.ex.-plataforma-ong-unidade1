## Descrição
<!-- Resumo do que foi implementado -->

## Tipo de mudança
- [ ] feat
- [ ] fix
- [ ] docs
- [ ] chore
- [ ] refactor

## Como testar
1. Passo 1...
2. Passo 2...

## Checklist
- [ ] Código comentado / limpo
- [ ] Testes manuais realizados
- [ ] Acessibilidade verificada
