# Contributing

Obrigado por contribuir! Por favor siga estas etapas:

1. Faça um fork do repositório.
2. Crie uma branch com o padrão: `feature/<ticket>-descricao` a partir de `develop`.
3. Abra um Pull Request para `develop` com descrição clara e checklist preenchido.
4. Mantenha commits pequenos e semânticos (Conventional Commits).
