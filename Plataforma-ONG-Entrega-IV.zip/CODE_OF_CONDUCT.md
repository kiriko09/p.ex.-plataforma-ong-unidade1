# Código de Conduta

Todos os contribuintes devem seguir um comportamento respeitoso e inclusivo. Qualquer linguagem ou comportamento discriminatório não será tolerado.
